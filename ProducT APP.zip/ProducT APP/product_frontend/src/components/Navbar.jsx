import React from 'react'
import { NavLink } from 'react-router-dom'

const Navbar = () => (
  <nav className="navbar navbar-expand-sm navbar-dark bg-dark">
    <div className="container">
      <NavLink className="navbar-brand fw-bold" to="/">ProductManagerApp</NavLink>
      <button className="navbar-toggler" type="button" data-bs-toggle="collapse"
        data-bs-target="#productNav" aria-controls="productNav" aria-expanded="false"
        aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="productNav">
        <ul className="navbar-nav ms-auto">
          <li className="nav-item"><NavLink className="nav-link" to="/">Products</NavLink></li>
          <li className="nav-item"><NavLink className="nav-link" to="/add">Add Product</NavLink></li>
        </ul>
      </div>
    </div>
  </nav>
)

export default Navbar
